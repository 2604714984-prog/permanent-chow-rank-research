# Reviewer reproduction package — v13 pure finite-combinatorial candidate

This reviewer candidate is dated 2026-08-10. Frozen v11 and v12 artifacts were
not overwritten.

## Claim and evidence boundary

- The manuscript states
  \(\operatorname{ChowRank}(\operatorname{perm}_3)=4\),
  \(\operatorname{ChowRank}(\operatorname{perm}_4)=8\), and
  \(\operatorname{ChowRank}(\operatorname{perm}_5)=16\).
- The \(n=5\) lower bound is now a **program-free finite-combinatorial
  characteristic-zero proof**: program output is not a logical premise.
  This does not mean that the proof is case-free or formally verified in a
  proof assistant.
- The former orbit--1 enumeration of all
  \(\binom{15}{10}=3003\) coordinate ten-planes has been replaced in the
  proof by a five-vertex closed formula, an exhaustive 48-block local table,
  ten Mobius-term families, and an eight-row \(K_4\) extremal table.
- The included exact rational programs are redundant diagnostics for
  transcription and implementation errors. Finite-field experiments, random
  diagnostics, SAT/DRAT, Groebner bases, and the historical 10GB file are not
  logical dependencies.
- `VALID` is the author's/internal dependency verdict. Independent external
  review is still pending.

## Minimal integrity and frontier diagnostic

From the extracted package root:

```text
python verify_manifest.py
python perm5_orbit1_terminal_pure_formula_audit.py
python perm5_orbit1_WM_same_row_valuative_small_lemmas_QQ_exact.py
```

Expected decisive output includes:

```text
PASS_MANIFEST_SHA256 files=100
PASS_EXACT_QQ_REDUNDANT_AUDIT_OF_PURE_GRAPH_FORMULA
all_subsets_formula_vs_QQ_checked=32768
ten_weight_subsets_checked=3003
maximum_p=36
maximum_count=4
lemma_2_1_rank_QQ=24
lemma_2_2_rank_QQ=25
```

These programs are cross-checks. The mathematical reason for the result is
the proof in the manuscript, especially (T1)--(T11), together with the route
1--8 structural lemmas.

## Rebuild the PDF

Requirements: Python 3, `pypdf`, XeLaTeX, and the LaTeX packages named by the
main source. Then run:

```text
cd latex/perm345_v13_pure
python build_pdf.py
```

The builder performs three XeLaTeX passes, regenerates the embedded manifest,
embeds all 101 reviewer files (100 manifest entries plus the manifest itself),
and checks the embedded filename set. The expected manuscript has 47 pages.

## Main files

- `perm345_chow_rank_v13_pure_reviewer_candidate_20260810.pdf` — AMS-style
  reviewer candidate with embedded sources and diagnostics.
- `latex/perm345_v13_pure/perm345_chow_rank_strict_proofs_zh_ams.tex` — master
  LaTeX source.
- `latex/perm345_v13_pure/formal_computation_spec.tex` — formal reconstruction
  and diagnostic specification.
- `latex/perm345_v13_pure/attachment_manifest.json` — byte counts and SHA-256
  values for all 100 source/diagnostic inputs.

The package contains no 10GB asset.
