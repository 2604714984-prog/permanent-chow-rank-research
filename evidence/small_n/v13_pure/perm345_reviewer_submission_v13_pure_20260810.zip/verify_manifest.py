#!/usr/bin/env python3
"""Verify every source and diagnostic against the embedded v13 manifest."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LATEX = ROOT / "latex" / "perm345_v13_pure"
MANIFEST = LATEX / "attachment_manifest.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest().upper()


payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
if payload.get("format") != "perm345-v13-pdf-attachment-manifest-v1":
    raise SystemExit("FAIL: unexpected manifest format")

checked = 0
for item in payload["files"]:
    name = item["name"]
    candidates = [path for path in (ROOT / name, LATEX / name) if path.is_file()]
    if len(candidates) != 1:
        raise SystemExit(f"FAIL: expected one file named {name}, found {candidates}")
    path = candidates[0]
    if path.stat().st_size != item["bytes"]:
        raise SystemExit(f"FAIL: byte count mismatch for {name}")
    if sha256(path) != item["sha256"].upper():
        raise SystemExit(f"FAIL: SHA-256 mismatch for {name}")
    checked += 1

print(f"PASS_MANIFEST_SHA256 files={checked}")
