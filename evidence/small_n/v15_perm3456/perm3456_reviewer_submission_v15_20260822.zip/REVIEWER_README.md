# `perm_3`, `perm_4`, `perm_5`, and `perm_6` v15 reviewer packet

This packet extends the repaired v14 small-case manuscript by adding the
post-audit exact ordinary-Chow-rank proof

\[
\operatorname{ChowRank}(\operatorname{perm}_6)=32
\]

over characteristic zero. The `n=3,4,5` proofs and their active certificates
are unchanged except for the unified A4 layout. The new `n=6` chapter contains
the permanent derivative tower, the small-intersection reduction, the
kernel-preimage lemma, the squarefree projected-symbol table, the repaired
half-defect estimate, the symmetric image-span inequality, and the global
filtration argument. Glynn's identity supplies the 32-term upper bound.

The `n=6` audit found that formal factor-label subproduct spaces do not equal
the actual derivative spaces in the five-dimensional profiles `s=2,3`. The
published proof does not use that shortcut. It differentiates the actual
normal forms, uses weaker sufficient rows, and freezes the rejected equalities
as negative regression tests.

## Scope

The claims concern ordinary Chow rank in characteristic zero. There is no
border-rank claim and no general-`n` equality. The finite calculations are
exact integer or rational computations. The packet is an internally audited
computer-assisted proof package; named external peer review and proof-assistant
formalization remain outstanding.

## Fail-closed verification

Python 3.11 or later is recommended. The `n=3`, `n=5`, and `n=6` active
verifiers use the standard library. The independent `n=4` replay requires
`python-flint==0.8.0`. From the extracted packet root, run:

```text
python -m pip install -r requirements-replay.txt
python verify_manifest.py
python replay_active_proof.py
```

The final lines must include:

```text
PACKAGE_VERIFY_PASS
PERM5_ONE_INTERSECTION_FLAG_STANDALONE_PASS
PASS: exact ordinary rank-32 finite proof payload matches
Ran 9 tests
OK
ACTIVE_PROOF_REPLAY_PASS
```

If XeLaTeX and `pypdf` are installed, rebuild the 46-page A4 PDF with:

```text
python replay_active_proof.py --with-pdf
```

The manuscript source is under `latex/perm3456_v15_repaired/`. The PDF embeds
the manuscript source, proof-facing programs, compact certificates, and an
attachment manifest. Missing files, identity mismatches, wrong finite counts,
rejected-equality regressions, or rank-table failures terminate with a nonzero
status.
